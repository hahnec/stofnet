# Chirp Ultrasound Dataset for StofNet

- TDK DK-CH101 Smartsonic Platform Sensor (see [sensor_specs.yaml](sensor_specs.yaml) for details)
- 3 target classes: 1) wooden ruler, 2) metal stick, 3) paper chart
- 100 measurements per distance (20 test, 80 train) at 9 distances
- *true distance* by average of manufacturer estimates
- *true measurements* by average of multiple acquisitions
- averaging is accomplished from 200 separate samples (not part of test and train)


Author: [Christopher Hahne](http://www.hahne.website) \
Email: <a href="&#x6d;&#x61;&#x69;&#x6c;&#x74;&#x6f;&colon;&#x69;&#x6e;&#x62;&#x6f;&#x78;&commat;&#x63;&#x68;&#x72;&#x69;&#x73;&#x74;&#x6f;&#x70;&#x68;&#x65;&#x72;&#x68;&#x61;&#x68;&#x6e;&#x65;&period;&#x64;&#x65;">&#x69;&#x6e;&#x62;&#x6f;&#x78;&#x20;&lsqb;&#x61;&#x74;&rsqb;&#x20;&#x63;&#x68;&#x72;&#x69;&#x73;&#x74;&#x6f;&#x70;&#x68;&#x65;&#x72;&#x68;&#x61;&#x68;&#x6e;&#x65;&#x20;&lsqb;&#x64;&#x6f;&#x74;&rsqb;&#x20;&#x64;&#x65;</a> \
Year: 2023


**CC-BY license**

<a rel="license" href="http://creativecommons.org/licenses/by/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/4.0/">Creative Commons Attribution 4.0 International License</a>.
